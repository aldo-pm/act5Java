
package com.mycompany.act5java;


public class main {
    public static void main (String ...args){
        int x,y,Suma,Resta,Multiplicación,División,Módulo;
        
        x=10;
        
        y=5;
        System.out.println("X = " +x);
        
        System.out.println("Y = " +y);
        
        Suma= x+y;
        System.out.println("Suma:" +Suma);
        
        Resta= x-y;
        System.out.println("Resta: " +Resta);
        
        Multiplicación= x*y;
        System.out.println("Multiplicación: " +Multiplicación);
        
        División= x/y;
        System.out.println("División: " +División);
        
        Módulo= x%y;
        System.out.println("Módulo: " +Módulo);
             
    }
}